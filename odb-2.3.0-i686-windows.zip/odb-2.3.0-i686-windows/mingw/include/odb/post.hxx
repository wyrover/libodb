// file      : odb/post.hxx
// copyright : Copyright (c) 2009-2013 Code Synthesis Tools CC
// license   : GNU GPL v2; see accompanying LICENSE file

#ifdef _MSC_VER
#  include <odb/compilers/vc/post.hxx>
#endif
