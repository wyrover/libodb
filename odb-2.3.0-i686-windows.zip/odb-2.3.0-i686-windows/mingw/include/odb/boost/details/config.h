/* odb/boost/details/config.h.  Generated from config.h.in by configure.  */
/* file      : odb/boost/details/config.h.in
 * copyright : Copyright (c) 2009-2013 Code Synthesis Tools CC
 * license   : GNU GPL v2; see accompanying LICENSE file
 */

/* This file is automatically processed by configure. */

#ifndef ODB_BOOST_DETAILS_CONFIG_H
#define ODB_BOOST_DETAILS_CONFIG_H

#define LIBODB_BOOST_STATIC_LIB 1

#endif /* ODB_BOOST_DETAILS_CONFIG_H */
